function W = buildWells(model, rock, fluid, T)
%BUILDWELLS Create wells from CSV

secondsPerYear = 365.25 * 24 * 3600;

rhoCO2 = 700;    % kg/m^3 (temporary)

fprintf("\n=====================================\n");
fprintf("Building Wells\n");
fprintf("=====================================\n");

W = [];

G = model.G;

nx = G.cartDims(1);
ny = G.cartDims(2);
nz = G.cartDims(3);

%----------------------------------------------------------
% Cartesian cell -> Active cell lookup
%----------------------------------------------------------
cartToActive = zeros(prod(G.cartDims), 1);

cartToActive(G.cells.indexMap) = 1:G.cells.num;

nInj = 0;
nProd = 0;

for i = 1:height(T)

    ix = T.Grid_X(i);
    iy = T.Grid_Y(i);

    k1 = T.PERF_FROM(i);
    k2 = T.PERF_TO(i);

    %------------------------------------------
    % Validate coordinates
    %------------------------------------------
    if ix < 1 || ix > nx || ...
       iy < 1 || iy > ny || ...
       k1 < 1 || k2 > nz || ...
       k1 > k2

        error("Invalid location for well %s.", ...
            string(T.Well_Bore_Name{i}));
    end

    %------------------------------------------
    % Convert (i,j,k) -> global cell indices
    %------------------------------------------
    cells = zeros(k2-k1+1,1);
    
    n = 1;
    
    for k = k1:k2
    
        % Cartesian cell index
        cartCell = sub2ind([nx ny nz], ix, iy, k);
    
        % Convert to active-cell numbering
        activeCell = cartToActive(cartCell);
    
        if activeCell == 0
            error("Well %s perforates inactive cell (%d,%d,%d).", ...
                string(T.Well_Bore_Name{i}), ix, iy, k);
        end
    
        cells(n) = activeCell;
        n = n + 1;
    
    end

    %------------------------------------------
    % Injector / Producer controls
    %------------------------------------------
    if T.Nature(i) == 1

        type = 'rate';

        % Placeholder
        targetTonnes = T.Target_tonnes_per_year(i);

        targetKgPerSec = targetTonnes * 1000 / secondsPerYear;
        
        val = targetKgPerSec / rhoCO2;
        fprintf("Injector %-15s : %.2f Mt/yr -> %.5f m^3/s\n", ...
        char(T.Well_Bore_Name{i}), ...
        targetTonnes/1e6, ...
        val);

        sign = 1;

        compi = [0 1];

        nInj = nInj + 1;

    else

        type = 'bhp';

        val = 300*barsa;
        fprintf("Producer %-15s : %.1f bar BHP\n", ...
        char(T.Well_Bore_Name{i}), ...
        val/barsa);

        sign = -1;

        % ignored for producers
        compi = [1 0];

        nProd = nProd + 1;

    end

    %------------------------------------------
    % Create well
    %------------------------------------------
    W = addWell( ...
        W, ...
        G, ...
        rock, ...
        cells, ...
        'Type', type, ...
        'Val', val, ...
        'Radius', 0.15, ...
        'Dir', 'z', ...
        'Name', char(T.Well_Bore_Name{i}), ...
        'Comp_i', compi, ...
        'Sign', sign);

end

fprintf("Injectors : %d\n", nInj);
fprintf("Producers : %d\n", nProd);
fprintf("Total      : %d\n", numel(W));
fprintf("=====================================\n");

end