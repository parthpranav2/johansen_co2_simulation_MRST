function T = readWellCSV(filename)
%READWELLCSV Read and validate the well configuration CSV

    if nargin == 0
        filename = "/Users/apple/Desktop/study/programming/Matlab/Plugins/MRST-2026a/core/examples/data/Johansen/HybridJohansen/input/well_loc.csv";
    end

    fprintf("\n=====================================\n");
    fprintf("Reading Well Configuration\n");
    fprintf("=====================================\n");

    T = readtable(filename);

    required = { ...
        'Well_Bore_Name', ...
        'NS_DEC_DEG', ...
        'EW_DEC_DEG', ...
        'PERF_FROM', ...
        'PERF_TO', ...
        'Nature', ...
        'Target_tonnes_per_year', ...
        'Start_Year', ...
        'End_Year'};

    for i = 1:numel(required)
        if ~ismember(required{i}, T.Properties.VariableNames)
            error("Missing required column: %s", required{i});
        end
    end

    fprintf("Loaded %d wells\n", height(T));

    % Convert if Nature is stored as text
    if iscell(T.Nature) || isstring(T.Nature)
        Nature = str2double(string(T.Nature));
    else
        Nature = T.Nature;
    end
    
    nInjectors = sum(Nature == 1);
    nProducers = sum(Nature == 0);
    
    fprintf("Injectors : %d\n", nInjectors);
    fprintf("Producers : %d\n", nProducers);

    fprintf("=====================================\n");

end