function schedule = buildSchedule(W)

    %% ----------------------------------------------------------
    % Simulation time
    % ----------------------------------------------------------

    totalTime = 10*year;

    nSteps = 100;

    dt = rampupTimesteps(totalTime, totalTime/nSteps);

    %% ----------------------------------------------------------
    % Allocate schedule
    % ----------------------------------------------------------

    schedule.step.val = dt;
    schedule.step.control = zeros(numel(dt),1);

    schedule.control = struct([]);

    %% ----------------------------------------------------------
    % Create one control per timestep
    % ----------------------------------------------------------

    currentTime = 0;

    for s = 1:numel(dt)

        currentYear = currentTime/year;

        Wstep = W;

        for w = 1:numel(W)

            if currentYear >= W(w).startYear && ...
               currentYear <  W(w).endYear

                Wstep(w).status = true;

            else

                Wstep(w).status = false;

            end

        end

        schedule.control(s).W = Wstep;
        schedule.step.control(s) = s;

        currentTime = currentTime + dt(s);

    end

    %% ----------------------------------------------------------
    % Summary
    % ----------------------------------------------------------

    fprintf("\n=====================================\n");
    fprintf("Simulation Schedule Created\n");
    fprintf("=====================================\n");
    fprintf("Total time : %.1f years\n", totalTime/year);
    fprintf("Timesteps  : %d\n", numel(dt));
    fprintf("Controls   : %d\n", numel(schedule.control));
    fprintf("=====================================\n");

end