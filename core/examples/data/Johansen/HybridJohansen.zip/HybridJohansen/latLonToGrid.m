function T = latLonToGrid(T, G)
%LATLONTOGRID Convert latitude/longitude to Johansen grid indices
%
% Inputs:
%   T - Well table returned by readWellCSV()
%   G - MRST grid structure
%
% Output:
%   T - Same table with added Grid_X and Grid_Y columns

    fprintf("\n=====================================\n");
    fprintf("Converting Coordinates -> Grid\n");
    fprintf("=====================================\n");

    %% -------------------------------------------------------
    % Reference location
    % -------------------------------------------------------
    refLat = 60.576425;
    refLon = 3.443367;

    % Corresponding grid location
    refX = 51;
    refY = 51;

    % Johansen cell size (metres)
    cellSize = 100;

    % Earth radius (m)
    R = 6378137;

    %% -------------------------------------------------------
    % Allocate
    % -------------------------------------------------------
    n = height(T);

    Grid_X = zeros(n,1);
    Grid_Y = zeros(n,1);

    %% -------------------------------------------------------
    % Convert each well
    % -------------------------------------------------------
    for k = 1:n

        lat = T.NS_DEC_DEG(k);
        lon = T.EW_DEC_DEG(k);

        % Northing (m)
        dNorth = deg2rad(lat - refLat) * R;

        % Easting (m)
        dEast = deg2rad(lon - refLon) * ...
                R * cos(deg2rad(refLat));

        % Convert metres -> grid index
        Grid_X(k) = round(refX + dEast / cellSize);
        Grid_Y(k) = round(refY + dNorth / cellSize);

    end

    %% -------------------------------------------------------
    % Store in table
    % -------------------------------------------------------
    T.Grid_X = Grid_X;
    T.Grid_Y = Grid_Y;

    %% -------------------------------------------------------
% Keep only wells inside the simulation grid
    %% -------------------------------------------------------
    
    nx = G.cartDims(1);
    ny = G.cartDims(2);
    
    inside = Grid_X >= 1 & Grid_X <= nx & ...
             Grid_Y >= 1 & Grid_Y <= ny;
    
    nRemoved = sum(~inside);
    
    if nRemoved > 0
        fprintf("Filtered out %d wells outside simulation grid.\n", nRemoved);
    end
    
    T = T(inside,:);
    
    T.Grid_X = Grid_X(inside);
    T.Grid_Y = Grid_Y(inside);
    %% -------------------------------------------------------
    % Summary
    % -------------------------------------------------------
    fprintf("Converted %d wells successfully.\n", n);

    fprintf("Grid X Range : %d -> %d\n", ...
        min(Grid_X), max(Grid_X));

    fprintf("Grid Y Range : %d -> %d\n", ...
        min(Grid_Y), max(Grid_Y));

    fprintf("=====================================\n");

end